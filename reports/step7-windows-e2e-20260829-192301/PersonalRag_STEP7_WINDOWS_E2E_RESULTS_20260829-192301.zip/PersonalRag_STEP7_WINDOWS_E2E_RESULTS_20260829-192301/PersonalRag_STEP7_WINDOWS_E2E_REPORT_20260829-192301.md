# PersonalRag V2 Step 7 Windows E2E verification report

Overall result: BLOCKED
The required Step 7 product lifecycle could not be completed because no supported initial index/store creation path and no runnable live NTFS/USN producer are present in the current main.

## Run and repository

Run timestamp: 2026-08-29T19:23:01.6141912+09:00
Repository: https://github.com/bokoprin/PersonalRag.git
Checkout: C:\shinsuke\app\PersonalRag
Origin: https://github.com/bokoprin/PersonalRag.git
Branch: main
HEAD: 60bd15a63218c7f9ef7d64757f99c8d07ed88107
HEAD tree: d86673acf409a72e459f13cfa8e3352910bbe763
git fetch --prune origin: PASS
git switch main: PASS
git pull --ff-only origin main: PASS, already up to date
Final git status --porcelain: PASS, empty
No commit, push, branch creation, reset, clean, or stash was performed.

## Source integrity

Status: FAIL
SOURCE_MANIFEST.sha256 contains 79 entries. The prescribed Get-FileHash SHA-256 verifier reported 79 mismatches in a clean fresh clone of this HEAD.
This result is not treated as canonical source acceptance. Full details are in source-integrity.txt.

## Documents read

Status: PASS
Read in full: README.md, DEVELOPMENT_RULES.md, STEP6_GUI_CANONICAL_2026-08-29.md, docs/V2_GUI.md, docs/V2_INCREMENTAL_INDEX.md, docs/V2_DOCUMENT_EXTRACTION.md, docs/PERFORMANCE_SLO.md.
The documents state that real Win32 execution, helper packaging, live NTFS/USN behavior, and target-Windows latency remain Step 7.

## Windows and toolchain baseline

WindowsProductName: Windows 10 Home
WindowsVersion: 2009
OsBuildNumber: 26200
OsArchitecture: 64 bit
rustc: 1.97.1 (8bab26f4f 2026-07-14)
cargo: 1.97.1 (c980f4866 2026-06-30)
git: 2.52.0.windows.1
Sealed Rust baseline 1.97.1: PASS
pdftotext on PATH: BLOCKED, where.exe could not find it
unzip on PATH: BLOCKED, where.exe could not find it
zstd on PATH: BLOCKED, where.exe could not find it

## Build and regression gates

| Check | Status | Evidence |
| --- | --- | --- |
| cargo fmt --all -- --check | PASS | cargo-fmt-check.txt, exit 0 |
| cargo clippy --offline --locked --all-targets -- -D warnings | FAIL | cargo-clippy.txt, exit 101, 5 errors in personalrag_gui.rs |
| cargo test --offline --locked | FAIL | cargo-test.txt, document_extraction 0/9 passed |
| cargo build --offline --locked --release | PASS | cargo-build-release.txt, exit 0 |
| target/release/personalrag-v2-gui.exe exists | PASS | 886784 bytes |

Raw regression total from the full command and independent focused reruns: 83 test cases, 71 PASS and 12 FAIL.
The 12 failures are 9 document extraction tests, 2 GUI focused tests, and 1 incremental focused test.
The 9 document failures include 8 missing-helper failures and 1 capacity-gate assertion failure.
Independent focused results: gui_search 0/2 PASS, incremental_index 18/19 PASS, metadata_index 5/5 PASS, p0_search 12/12 PASS, persistent_index 8/8 PASS, search_semantics 6/6 PASS. The 22 library unit tests also PASS.

## Initial index/store precondition

Status: BLOCKED
BLOCKER S7-INIT-001
No documented or supported end-user path was found to create a valid Step 1-5 index store for an arbitrary indexed root.
The GUI entrypoint only parses root/store and calls bundle loading. The personalrag-v2-bench and persistent_bench programs are benchmark or internal helpers, not a documented end-user indexing lifecycle. They were not used as a workaround.
The disposable corpus therefore has no product-compatible store, and GUI search acceptance cannot be claimed.
Evidence: initial-index-path.txt

## Disposable corpus

Status: PASS
Root: C:\Users\bokop\AppData\Local\Temp\PersonalRag-Step7-20260829-191100-e223ee41
Created outside the repository and contains 7 files, 328 bytes.
Files: text/alpha.txt, text/bravo.log, path-case/MixedCaseName.TXT, rename/before-rename.txt, move/before-move.txt, modify/modify-me.txt, delete/delete-me.txt.
Unique markers and SHA-256 values are recorded in disposable-corpus.json.
No source or user files were modified or deleted.

## GUI smoke

All items below are BLOCKED by S7-INIT-001 because a valid root/store pair was unavailable.
| Item | Status | Reason |
| --- | --- | --- |
| window opens and closes cleanly with valid store | BLOCKED | S7-INIT-001 |
| File/path field | BLOCKED | S7-INIT-001 |
| Content field | BLOCKED | S7-INIT-001 |
| Full path control | BLOCKED | S7-INIT-001 |
| Case sensitive control | BLOCKED | S7-INIT-001 |
| Literal selector | BLOCKED | S7-INIT-001 |
| Regex selector | BLOCKED | S7-INIT-001 |
| Wildcard selector | BLOCKED | S7-INIT-001 |
| result list | BLOCKED | S7-INIT-001 |
| preview | BLOCKED | S7-INIT-001 |
| Open | BLOCKED | S7-INIT-001 |
| Show in Explorer | BLOCKED | S7-INIT-001 |
| Reload index | BLOCKED | S7-INIT-001 |
| More | BLOCKED | S7-INIT-001 |
| typing responsiveness | BLOCKED | S7-INIT-001 |
| resize responsiveness | BLOCKED | S7-INIT-001 |

An auxiliary invalid-invocation check was executed. Computer Use observed a single returned PersonalRag V2 usage dialog, including the required root/store usage text, and the Return key closed it. A separate empty-store launch returned a window title of PersonalRag V2 and CloseMainWindow exited the process. This is PASS only for safe invalid-invocation handling; it is not valid-store GUI acceptance.

## Search E2E matrix

All items below are BLOCKED by S7-INIT-001. No result count or representative path was fabricated.
| Search case | Status |
| --- | --- |
| filename alpha to alpha.txt | BLOCKED |
| Full path Windows fragment | BLOCKED |
| case-insensitive filename MIXEDCASENAME.TXT | BLOCKED |
| case-sensitive wrong casing | BLOCKED |
| literal shared content to alpha and bravo | BLOCKED |
| filename alpha AND shared content | BLOCKED |
| Regex ERROR_[0-9]{4} | BLOCKED |
| Wildcard *ONLY_* | BLOCKED |
| Japanese marker and readable preview | BLOCKED |
| case-sensitive content | BLOCKED |
| preview marker and UTF-8 integrity | BLOCKED |
| More enumeration | BLOCKED |

## Windows shell integration

| Item | Status |
| --- | --- |
| Open with Windows default application | BLOCKED |
| Show in Explorer and select correct file | BLOCKED |
No valid search result was available, so no shell action was issued against a real result.

## PDF and Office

| Format | Status | Reason |
| --- | --- | --- |
| PDF | BLOCKED | helper pdftotext missing and no valid store |
| DOCX | BLOCKED | helper unzip missing and no valid store |
| XLSX | BLOCKED | helper unzip missing and no valid store |
| PPTX | BLOCKED | helper unzip missing and no valid store |
No invalid document fixture was used as a substitute for a real document.

## Live NTFS/USN

Status: BLOCKED
BLOCKER S7-USN-001
The Windows USN adapter and platform-independent normalizer exist in source, but no runnable product process, service, or command wires live journal consumption to updated Step 4 bundle publication.
The create, modify, rename, move, and delete live tests were not issued because the required producer is absent.
Evidence: usn-runnable-path.txt

## Restart, reload, corruption recovery

| Item | Status | Reason |
| --- | --- | --- |
| close and relaunch against the same valid store | BLOCKED | S7-INIT-001 |
| Reload index and repeat searches | BLOCKED | S7-INIT-001 |
| corrupt disposable store copy and verify fail closed | BLOCKED | S7-INIT-001 |
The invalid-argument usage dialog check above was independent and PASS, but it does not replace the valid-store corruption test.

## Performance and usability evidence

| Metric | Status | Result |
| --- | --- | --- |
| indexed file count | BLOCKED | no product index was created |
| persistent store bytes | BLOCKED | no product index was created |
| release EXE size | PASS | 886784 bytes |
| launch-to-usable time | BLOCKED | no valid store |
| filename first-result latency | BLOCKED | no valid store |
| content first-result latency | BLOCKED | no valid store |
| live change-to-searchable latency | BLOCKED | S7-USN-001 |
| typing and resizing responsiveness | BLOCKED | no valid store window |
| keyboard and Tab reachability | BLOCKED | no valid store window |
| Japanese rendering | BLOCKED | no valid search result |
| normal DPI usability | BLOCKED | no valid store window |
No p50, p95, or p99 values were fabricated from manual observation.

## Failure and blocker records

### S7-BUILD-001
Status: FAIL
Severity: High
Area: source integrity
Preconditions: clean checkout of current main
Steps to reproduce: run the prescribed SOURCE_MANIFEST.sha256 Get-FileHash verifier
Expected: all 79 manifest entries match
Actual: 79 of 79 entries mismatch
Evidence/log: source-integrity.txt
Reproducible: yes in this fresh clone

### S7-BUILD-002
Status: FAIL
Severity: Medium
Area: clippy sealed gate
Preconditions: Rust 1.97.1 and clean current main
Steps to reproduce: cargo clippy --offline --locked --all-targets -- -D warnings
Expected: exit 0
Actual: exit 101. Five errors are reported in src/bin/personalrag_gui.rs: four collapsible_if and one needless_update.
Evidence/log: cargo-clippy.txt
Reproducible: yes

### S7-DOC-001
Status: BLOCKED
Severity: High
Area: PDF and Office extraction
Preconditions: cargo test --offline --locked with no helper executables on PATH
Steps to reproduce: run cargo test --offline --locked
Expected: document extraction tests execute with the required helpers
Actual: pdftotext, unzip, and zstd are absent from PATH; 8 tests fail with program not found.
Evidence/log: baseline-toolchain.txt and cargo-test.txt
Reproducible: yes

### S7-DOC-002
Status: FAIL
Severity: Medium
Area: document capacity gate regression
Preconditions: same cargo test command
Steps to reproduce: run cargo test --offline --locked
Expected: verification_capacity_hard_gate_fails_closed_before_publish passes
Actual: assertion at tests/document_extraction.rs:355 fails because the returned error does not match CapacityExceeded.
Evidence/log: cargo-test.txt
Reproducible: yes

### S7-GUI-001
Status: FAIL
Severity: High
Area: GUI search-session regression
Preconditions: Windows Rust 1.97.1, focused GUI test target
Steps to reproduce: cargo test --offline --locked --test gui_search
Expected: 2 tests pass
Actual: 0 pass and 2 fail. gui_session_searches_metadata_content_and_intersection returns 0 rows where 1 is expected. gui_session_supports_literal_regex_wildcard_and_case_mode returns 0 rows where 2 are expected.
Evidence/log: focused-regression-191242.txt
Reproducible: yes

### S7-INCREMENTAL-001
Status: FAIL
Severity: Medium
Area: incremental content limits regression
Preconditions: Windows Rust 1.97.1, focused incremental test target
Steps to reproduce: cargo test --offline --locked --test incremental_index
Expected: additive_content_limits_bound_file_enumeration_without_changing_first_batch_api passes
Actual: assertion at tests/incremental_index.rs:765 sees 1 first-batch file where 2 are expected; 18 of 19 tests pass.
Evidence/log: focused-regression-191242.txt
Reproducible: yes

### S7-INIT-001
Status: BLOCKED
Severity: Blocker
Area: initial indexing lifecycle
Preconditions: fresh disposable root and current product source
Steps to reproduce: inspect documented launch contract and all executable entrypoints, then attempt to identify a supported arbitrary-root initial store creator
Expected: a documented product command or provided compatible store exists
Actual: GUI only loads an existing bundle; available benchmark/internal helpers are not a supported end-user lifecycle. No valid store was created.
Evidence/log: initial-index-path.txt
Reproducible: yes

### S7-USN-001
Status: BLOCKED
Severity: Blocker
Area: live NTFS incremental publication
Preconditions: NTFS Windows host and current source
Steps to reproduce: inspect USN adapter symbols and runnable entrypoints
Expected: a runnable component consumes live USN changes and publishes Step 4 bundles
Actual: adapter and normalizer source exist, but no runnable producer/service/command is wired to bundle publication.
Evidence/log: usn-runnable-path.txt
Reproducible: yes

## Evidence files

Run evidence directory: C:\Users\bokop\AppData\Local\PersonalRag\Step7-20260829-190755
Report: C:\Users\bokop\AppData\Local\PersonalRag\Step7-20260829-190755\PersonalRag_STEP7_WINDOWS_E2E_REPORT_20260829-192301.md
Commands: C:\Users\bokop\AppData\Local\PersonalRag\Step7-20260829-190755\PersonalRag_STEP7_WINDOWS_E2E_COMMANDS_20260829-192112.txt
Logs: C:\Users\bokop\AppData\Local\PersonalRag\Step7-20260829-190755\PersonalRag_STEP7_WINDOWS_E2E_LOGS_20260829-192301.txt
Other evidence: baseline-toolchain.txt, cargo-fmt-check.txt, cargo-clippy.txt, cargo-test.txt, cargo-build-release.txt, focused-regression-191242.txt, source-integrity.txt, initial-index-path.txt, usn-runnable-path.txt, gui-invalid-store.txt, final-verification.txt, disposable-corpus.json.

## Status counts

The following counts cover 14 preflight/build/checklist rows plus 51 required Step 7 product rows. Raw test-case counts are reported separately above.
PASS: 8
FAIL: 3
BLOCKED: 54
SKIP: 0

## Conclusion

Step 7 Windows E2E is BLOCKED and is not complete. The current main was fetched and verified clean at the recorded HEAD, but product acceptance cannot be declared until a supported initial index/store creation path and a runnable live NTFS/USN bundle producer are supplied. The source-integrity, clippy, document, GUI focused, and incremental failures are recorded without source changes.

